﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Microsoft.Web.WebPages.OAuth;
using WebMatrix.WebData;
using ContractMvcWeb.Models;
using ContractMvcWeb.Models.Beans;

namespace ContractMvcWeb.Controllers
{
    //[MyAuthorize]
    public class AccountController : Controller
    {
        //
        // GET: /Account/Login                                 
        //[AllowAnonymous]
        //public ActionResult Login(string returnUrl)
        //{
        //    ViewBag.ReturnUrl = returnUrl;
        //    return View();
        //}

        //
        // POST: /Account/Login     
        //[HttpPost]
        //[AllowAnonymous]
        //[ValidateAntiForgeryToken]
        //public ActionResult Login(LoginModel model, string returnUrl)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        AccountContext dbContext = new AccountContext();
        //        User userObj = dbContext.Login(model.UserName, model.Password);
        //        if ( userObj != null)
        //        {
        //            //List<userrole> roles = dbContext.GetRoles(personObj.userid);                    
        //            //System.Web.Script.Serialization.JavaScriptSerializer js = new System.Web.Script.Serialization.JavaScriptSerializer();
        //            //string jsstr = js.Serialize(roles); 

        //            int expiration = 0;
        //            if (!int.TryParse(System.Configuration.ConfigurationManager.AppSettings["Expiration"].ToString(), out expiration))
        //            {
        //                expiration = 5;
        //            }

        //            FormsAuthenticationTicket ticket = new FormsAuthenticationTicket(1, model.UserName, DateTime.Now,
        //                DateTime.Now.AddMinutes( expiration ), false , string.Empty );
                  
                    
        //            string ticketEncrypt = FormsAuthentication.Encrypt( ticket );
        //            System.Web.HttpCookie cookie = new HttpCookie(FormsAuthentication.FormsCookieName, ticketEncrypt);
        //            System.Web.HttpContext.Current.Response.Cookies.Add(cookie);                    

        //            return RedirectToLocal(returnUrl);
        //        }
        //        else
        //        {
        //            ModelState.AddModelError("", "提供的用户名或密码不正确。");
        //            return View(model);
        //        }
        //    }

        //    // 如果我们进行到这一步时某个地方出错，则重新显示表单
        //    ModelState.AddModelError("", "提供的用户名或密码不正确。");
        //    return View(model);
        //}


        [HttpPost]
        [AllowAnonymous]
        public JsonResult LoginRestfull(string userName, string password)
        {
            try
            {
                if (string.IsNullOrEmpty(userName) || string.IsNullOrEmpty(password))
                {
                    Result result = new Result((int)ResultCodeEnum.Error, "用户名或密码空!", null);
                    JsonResult jr = new JsonResult();
                    jr.Data = result;
                    jr.JsonRequestBehavior = JsonRequestBehavior.AllowGet;
                    return jr;
                }
                AccountContext dbContext = new AccountContext();
                ContractMvcWeb.Models.Beans.User userObj = dbContext.Login(userName, password);
                if (userObj != null)
                {
                    //List<userrole> roles = dbcontext.GetRoles(userobj.userid);
                    //System.Web.Script.Serialization.JavaScriptSerializer js = new System.Web.Script.Serialization.JavaScriptSerializer();
                    //string jsstr = js.Serialize(roles);
                    Result result = null;
                    JsonResult jr = null;
                    if (userObj.enable == (int)EnableEnum.DISABLE)
                    {
                        result = new Result((int)ResultCodeEnum.Error ,"该用户被禁止登录。",null);
                        jr = new JsonResult();
                        jr.Data = result;
                        return jr;
                    }

                    int expiration = 0;
                    if (!int.TryParse(System.Configuration.ConfigurationManager.AppSettings["Expiration"].ToString(), out expiration))
                    {
                        expiration = 30;
                    }

                    FormsAuthenticationTicket ticket = new FormsAuthenticationTicket(1, userName, DateTime.Now,
                        DateTime.Now.AddMinutes(expiration), false, string.Empty);

                    string ticketEncrypt = FormsAuthentication.Encrypt(ticket);
                    System.Web.HttpCookie cookie = new HttpCookie(FormsAuthentication.FormsCookieName, ticketEncrypt);
                    System.Web.HttpContext.Current.Response.Cookies.Add(cookie);

                    result = new Result((int)ResultCodeEnum.Success, "", userObj);
                    jr = new JsonResult();
                    jr.Data = result;
                    return jr;
                }
                else
                {
                    Result result = new Result((int)ResultCodeEnum.Error, "用户名或密码错误!", null);
                    JsonResult jResult = new JsonResult();
                    jResult.Data = result;
                    return jResult;
                }
            }
            catch (Exception ex)
            {
                JsonResult jr = new JsonResult();
                jr.Data = new Result((int)ResultCodeEnum.Error, ex.Message, "");
                return jr;
            }
        }

        /// <summary>
        /// 退出系统
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public JsonResult LogoutRestfull()
        {
            Result result = null;
            try
            {
                FormsAuthentication.SignOut();

                if (HttpContext.Response.Cookies != null)
                {
                    int count = HttpContext.Response.Cookies.Count;
                    for(int i =0;i<count ;i++ )
                    {
                        HttpCookie c = HttpContext.Response.Cookies[i];
                        c.Expires = DateTime.Now.AddDays(-1);
                    }
                    HttpContext.Response.Cookies.Clear();                       
                }
            }
            catch (Exception ex)
            {                    
                result = new Result((int)ResultCodeEnum.Error, ex.Message,null );
                JsonResult jr3 = new JsonResult();
                jr3.Data = result;
                return jr3;
            }


            result = new Result((int)ResultCodeEnum.Success, "", null);
            JsonResult jr = new JsonResult();
            jr.Data = result;
            return jr;
        }

        //
        // POST: /Account/LogOff

        ////[HttpPost]
        ////[ValidateAntiForgeryToken]
        //public ActionResult Logout()
        //{
        //    //WebSecurity.Logout();

        //    FormsAuthentication.SignOut();

        //    return RedirectToAction("Contractlist", "Contract");
        //}

        //
        // GET: /Account/Register   
        //[AllowAnonymous]
        //public ActionResult Register()
        //{
        //    return View();
        //}  

        //[HttpPost]
        //[AllowAnonymous]
        //[ValidateAntiForgeryToken]
        //public ActionResult Register(ContractMvcWeb.Models.RegisterModel model)
        //{
        //    AccountContext dbContext = new AccountContext();
            

        //    // 如果我们进行到这一步时某个地方出错，则重新显示表单
        //    return View(model);
        //}      
                  

       
        #region 帮助程序
        //private ActionResult RedirectToLocal(string returnUrl)
        //{
        //    if (Url.IsLocalUrl(returnUrl))
        //    {
        //        return Redirect(returnUrl);
        //    }
        //    else
        //    {
        //        return RedirectToAction("ContractList", "Contract");
        //    }
        //}

        //public enum ManageMessageId
        //{
        //    ChangePasswordSuccess,
        //    SetPasswordSuccess,
        //    RemoveLoginSuccess,
        //}

       

        //private static string ErrorCodeToString(MembershipCreateStatus createStatus)
        //{
        //    // 请参见 http://go.microsoft.com/fwlink/?LinkID=177550 以查看
        //    // 状态代码的完整列表。
        //    switch (createStatus)
        //    {
        //        case MembershipCreateStatus.DuplicateUserName:
        //            return "用户名已存在。请输入其他用户名。";

        //        case MembershipCreateStatus.DuplicateEmail:
        //            return "该电子邮件地址的用户名已存在。请输入其他电子邮件地址。";

        //        case MembershipCreateStatus.InvalidPassword:
        //            return "提供的密码无效。请输入有效的密码值。";

        //        case MembershipCreateStatus.InvalidEmail:
        //            return "提供的电子邮件地址无效。请检查该值并重试。";

        //        case MembershipCreateStatus.InvalidAnswer:
        //            return "提供的密码取回答案无效。请检查该值并重试。";

        //        case MembershipCreateStatus.InvalidQuestion:
        //            return "提供的密码取回问题无效。请检查该值并重试。";

        //        case MembershipCreateStatus.InvalidUserName:
        //            return "提供的用户名无效。请检查该值并重试。";

        //        case MembershipCreateStatus.ProviderError:
        //            return "身份验证提供程序返回了错误。请验证您的输入并重试。如果问题仍然存在，请与系统管理员联系。";

        //        case MembershipCreateStatus.UserRejected:
        //            return "已取消用户创建请求。请验证您的输入并重试。如果问题仍然存在，请与系统管理员联系。";

        //        default:
        //            return "发生未知错误。请验证您的输入并重试。如果问题仍然存在，请与系统管理员联系。";
        //    }
        //}
        #endregion
    }
}
