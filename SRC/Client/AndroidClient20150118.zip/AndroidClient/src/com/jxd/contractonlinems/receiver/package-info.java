/**
 *
 */
/**
 * @author ��
 *
 */
package com.jxd.contractonlinems.receiver;